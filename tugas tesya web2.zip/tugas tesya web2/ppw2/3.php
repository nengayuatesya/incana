<?php 
	$my_file = 'example.txt';
	$handle = fopen($my_file, 'a') or die('cannot open file: '.$my_file);
	$data = 'new data line 1';
	fwrite($handle, $data);
	$new_data = "\n".'new data line 2';
	fwrite($handle, $new_data);
	fclose($handle);
?>