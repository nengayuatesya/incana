<?php
	include('koneksi.php');
	$sql =mysql_query("SELECT * FROM file ORDER BY id_file DESC");
    if(mysql_num_rows($sql) > 0){
	$no = 1;
	while($data = mysql_fetch_assoc($sql)){
		echo '
		<tr bgcolor="#fff">
		   <td align="center">'.$no. '</td>
		   <td 
align="center">'.$data['tgl_upload'].'</td>
<td><a 
href="'$data['file']'">'.$data['nama_file'].'</a></td>
<td 
align="center">'.|$data['tipe_file'].'</td>
<td 
align="center">'.$data['ukuran_file'].'</td>
</tr>
';
$no++;
}
}else{
	echo '
	<tr bgcolor="#fff">
	<td align="center" colspan="4"
	align="center">Tidal ada data!</td>
</tr>
';
}
?>
</table>
</p>
</div>
</div>
</body>