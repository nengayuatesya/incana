<?php
	$my_file = 'example.txt';
	$handle = fopen ($my_file, 'w') or die ('cannot open file: '.$my_file);
?>