<?php 
	include('koneksi.php');
	$query		="SELECT id_file FROM file ORDER BY id_file DESC LIMIT 
0,1";
	$execute	=mysql_query($query);
	$cek 		=mysql_num_rows($execute);
	$get_data 	=mysql_fetch_array($execute);
	$file_nama 		= $_FILES['file'] ['nama'];
	$file_ext 		= $_FILES['file'] ['type'];
	$file_size 		= $_FILES['file'] ['size'];
	$file_tmp 		= $_FILES['file'] ['tmp_nama'];
	$nama 			= $_POST['nama'];
	$tgl 			= date("Y-m-d");

	if($file_size < 1044070){
		if ($cek<>0){
			$id = $get_data['id_file']+1;
		}else{
			$id = 1;
		}
		$lokasi = 'files/'.basename($id. ".$file_name");
		move_uploaded_file($file_tmp, $lokasi);

		$in = mysql_query("INSERT INTO file VALUES('$id','$tgl','$file_nama','$file_ext','$file_size')") or die (mysql_error());
			if($in){
				echo 'div class="ok">SUCCESS: File berhasil di upload!
		</div>';
		    }else{
		    	echo 'div class="error">ERROR: Gagal upload file!</div>';
		    }
		   }else{
		   	echo '<div class="error">ERROR: Besar ukuran file (file size)
		 maksimal 1 mb!</div>';
		}
