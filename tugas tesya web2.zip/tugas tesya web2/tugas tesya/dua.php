<?php 
	$my_file = 'tugas pw 2';
	$handle = 'fopen'($my_file, 'r');
	$data = fread($handle, filesize($my_file));
	if ($data<>''){
			echo $data;
		}else{
			echo "<span style=color:red>Data file kosong<span>";
		}
	?>