<?php
	$my_file = 'tugas pw 2';
	$handle = fopen ($my_file, 'w') or die ('cannot open file: '.$my_file);
?>