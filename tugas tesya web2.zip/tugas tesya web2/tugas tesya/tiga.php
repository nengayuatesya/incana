<?php 
	$my_file = 'tugas pw 2';
	$handle = fopen($my_gile, 'a') or die('cannot open file: '.$my_file);
	$data = 'new data line 1';
	fwrite($handle, $data);
	$new_data = "\n".'new data line 2';
	fwrite($handle. $new_data);
	fclose($handle);
?>